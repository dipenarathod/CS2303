/*
 * Checker.cpp
 *
 *  Created on: Sep 23, 2021
 *      Author: Dipen
 */

#include "Checker.h"

Checker::Checker() {
	// TODO Auto-generated constructor stub

}

Checker::~Checker() {
	// TODO Auto-generated destructor stub
}

void Checker::moveDiagonalLeft(){
	if(this->getPlayerColor()=='b'){
		this->col-=1;
		this->row-=1;
	}
	else{
		this->row+=1;
		this->col+=1;
	}
}

void Checker::moveDiagonalRight(){
	if(this->getPlayerColor()=='b'){
			this->col+=1;
			this->row-=1;
		}
		else{
			this->row+=1;
			this->col-=1;
		}
}

void Checker::setRow(int row){
	this->row=row;
}

void Checker::setColumn(int col){
	this->col=col;
}

void Checker::setPlayerColor(char color){
	this->playerColor=color;
}

int Checker::getRow(){
	return this->row;
}

int Checker::getCol(){
	return this->col;
}

char Checker::getPlayerColor(){
	return this->playerColor;
}
