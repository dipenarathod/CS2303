/*
 * CheckerMove.h
 *
 *  Created on: Aug 2, 2021
 *      Author: theresesmith
 */

#ifndef CHECKERMOVE_H_
#define CHECKERMOVE_H_

class CheckerMove {
public:
	CheckerMove();
	virtual ~CheckerMove();
};

#endif /* CHECKERMOVE_H_ */
