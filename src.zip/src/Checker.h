/*
 * Checker.h
 *
 *  Created on: Sep 23, 2021
 *      Author: Dipen
 */

#ifndef CHECKER_H_
#define CHECKER_H_

class Checker {
public:
	Checker();
	virtual ~Checker();
	void moveDiagonalRight();
	void moveDiagonalLeft();
	void setRow(int);
	void setColumn(int);
	void setPlayerColor(char);
	int getRow();
	int getCol();
	char getPlayerColor();
private:
	int row;
	int col;
	char playerColor;
	bool isKing;
};
class King:public Checker{
public:
	King();
	void moveBackDiagonalRight();
	void moveBackDiagonalLeft();
};

#endif /* CHECKER_H_ */
