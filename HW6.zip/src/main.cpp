//============================================================================
// Name        : Battleship_cpp.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "Fleet.h"
#include "Production.h"
using namespace std;

int main() {
	Production* prod=new Production();
	prod->production();
}
